package core;

public class World {

    // build your own world!

}
