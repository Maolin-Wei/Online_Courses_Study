package core;

public class Main {
    public static void main(String[] args) {

        // build your own world!


    }
}
