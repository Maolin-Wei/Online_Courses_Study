package deque;

public class LinkedListDeque<T> implements Deque<T> {

}
