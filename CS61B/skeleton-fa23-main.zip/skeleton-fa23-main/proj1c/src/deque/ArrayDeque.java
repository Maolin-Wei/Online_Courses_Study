package deque;

public class ArrayDeque<T> implements Deque<T> {

}
