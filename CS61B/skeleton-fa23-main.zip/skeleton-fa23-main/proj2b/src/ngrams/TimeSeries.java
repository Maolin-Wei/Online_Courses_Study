package ngrams;

import java.util.List;
import java.util.TreeMap;

/**
 * A placeholder implementation of TimeSeries.
 */
public class TimeSeries extends TreeMap<Integer, Double> {
    public List<Integer> years() {
        throw new UnsupportedOperationException();
    }

    public List<Double> data() {
        throw new UnsupportedOperationException();
    }
}
